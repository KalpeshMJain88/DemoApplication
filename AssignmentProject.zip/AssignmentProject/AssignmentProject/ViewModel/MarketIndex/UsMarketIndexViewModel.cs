﻿using AssignmentProject.Controls;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentProject.ViewModel.MarketIndex
{
    public class UsMarketIndexViewModel : BaseViewModel, ITabControlItem
    {
        public ObservableCollection<Index> UsIndexData { get; set; }


        private string _title;
        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
            }
        }


        private string _toolTipTitle;
        public string ToolTipTitle
        {
            get { return _toolTipTitle; }
            set
            {
                _toolTipTitle = value;

            }
        }

        private object _content;
        public object Content
        {
            get { return _content; }
            set
            {
                _content = value;
            }
        }

        private TabView view;
        public TabView View
        {
            get { return view; }
            set
            {
                view = value;

            }
        }
        public UsMarketIndexViewModel()
        {
            UsIndexData = new ObservableCollection<Index>(new List<Index>
            {
                new Index{ IndexName = "S&P 500",Value=5000,Change="4.0%"},
                new Index{ IndexName = "Nasdaq",Value=200,Change="4.0%"},
                new Index{ IndexName = "Cac",Value=300,Change="4.0%"},
                new Index{ IndexName = "Dac",Value=800,Change="4.0%"},
                new Index{ IndexName = "Dac 500",Value=500,Change="4.0%"},
                new Index{ IndexName = "S&P 500",Value=5620,Change="4.0%"},
                new Index{ IndexName = "Bank S&P 500",Value=5000,Change="4.0%"},
                new Index{ IndexName = "Kospi",Value=5000,Change="4.0%"},
                new Index{ IndexName = "FTSE",Value=5000,Change="4.0%"},
                new Index{ IndexName = "Shangai",Value=5000,Change="4.0%"},
                new Index{ IndexName = "S&P 500",Value=5000,Change="4.0%"},

            });
        }
    }
}
