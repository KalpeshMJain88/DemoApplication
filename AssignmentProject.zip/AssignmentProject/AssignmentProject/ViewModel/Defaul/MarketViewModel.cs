﻿using AssignmentProject.Controls;
using AssignmentProject.View;
using AssignmentProject.View.MarketIndex;
using AssignmentProject.ViewModel.MarketIndex;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace AssignmentProject.ViewModel
{
    public class MarketViewModel : BaseViewModel,ITabControlItem
    { 
        public ITabControlItem MarketMoverCurrentTab { get; set;}
        public ITabControlItem MarketIndexCurrentTab { get; set; }
        public ITabControlItem MarketExtraCurrentTab { get; set; }
        public ITabControlItem MarketView1CurrentTab { get; set; }
        public ITabControlItem MarketView2CurrentTab { get; set; }
        public MarketViewModel()
        {
            MarketMoverTabs = GetMarketMoverTabs();
            MarketIndexTabs = GetMarketIndexTabs();
            MarketExtraTabs = GetMarketExtraTabs();
            MarketView1Tabs = GetMarketView1Tabs();
            MarketView2Tabs = GetMarketView2Tabs();

            //Set Current Tab as Default;
            MarketMoverCurrentTab = MarketMoverTabs[0];

            MarketIndexCurrentTab = MarketIndexTabs[0];

            MarketExtraCurrentTab = MarketExtraTabs[0];

            MarketView1CurrentTab = MarketView1Tabs[0];

            MarketView2CurrentTab = MarketView2Tabs[0];
        }

        public ObservableCollection<ITabControlItem> GetMarketMoverTabs()
        {
            var tabs = new List<ITabControlItem>();

            var mmView = new EuropeMarketMoverView();
            var mmVM = new EuropeMarketMoverViewModel();
            mmView.DataContext = mmVM;
            mmVM.Title = "Europe Move";
            mmVM.ToolTipTitle = "Europe Scripts";
            mmVM.Content = mmView;

            tabs.Add(mmVM);

            var mmView1 = new UsMarketMoverView();
            var mmVM1 = new UsMarketMoverViewModel { Content = mmView1, Title = "US Move", ToolTipTitle = "Us Market Moves" };
            mmView1.DataContext = mmVM1;
            tabs.Add(mmVM1);

            var mmView2 = new JpMarketMoverView();
            var mmVM2 = new JpMarketMoverViewModel { Content = mmView1, Title = "JP Move", ToolTipTitle = "Jp Market Moves" };
            mmView2.DataContext = mmVM2;

            tabs.Add(mmVM2);

            return new ObservableCollection<ITabControlItem>(tabs);
        }
        private string _title;
        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
            }
        }

        private string _toolTipTitle;
        public string ToolTipTitle
        {
            get { return _toolTipTitle; }
            set
            {
                _toolTipTitle = value;
            }
        }

        private object _content;
        public object Content
        {
            get { return _content; }
            set
            {
                _content = value;

            }
        }
        private TabView view;
        public TabView View
        {
            get { return view; }
            set
            {
                view = value;
            }
        }
        public ObservableCollection<ITabControlItem> MarketMoverTabs { get; set; }
        public ObservableCollection<ITabControlItem> MarketIndexTabs { get; set; }
        public ObservableCollection<ITabControlItem> MarketExtraTabs { get; set; }
        public ObservableCollection<ITabControlItem> MarketView1Tabs { get; set; }
        public ObservableCollection<ITabControlItem> MarketView2Tabs { get; set; }

        public ObservableCollection<ITabControlItem> GetMarketView1Tabs()
        {
            var tabs = new List<ITabControlItem>();

            var mmView = new UsMarketIndexView();
            var mmVM = mmView.DataContext as UsMarketIndexViewModel;
            mmVM.Content = mmView;

            mmVM.Title = "Market US View 1";
            mmVM.ToolTipTitle = "Market US View 1 Details";

            tabs.Add(mmVM);

            var mmView1 = new JpMarketIndexView();
            var mmVM1 = new JpMarketIndexViewModel();
            mmVM1.Content = mmView1;
            mmView1.DataContext = mmVM1;
            mmVM1.Title = "Market JP View 1";
            mmVM1.ToolTipTitle = "Market JP View 1 Details";

            tabs.Add(mmVM1);

            return new ObservableCollection<ITabControlItem>(tabs);
        }
        public ObservableCollection<ITabControlItem> GetMarketView2Tabs()
        {
            var tabs = new List<ITabControlItem>();

            var mmView = new UsMarketIndexView();
            var mmVM = mmView.DataContext as UsMarketIndexViewModel;
            mmVM.Content = mmView;

            mmVM.Title = "Market US View 2";
            mmVM.ToolTipTitle = "Market US View 2 Details";

            tabs.Add(mmVM);

            var mmView1 = new JpMarketIndexView();
            var mmVM1 = new JpMarketIndexViewModel();
            mmVM1.Content = mmView1;
            mmView1.DataContext = mmVM1;
            mmVM1.Title = "Market JP View 2";
            mmVM1.ToolTipTitle = "Market JP View 2 Details";

            tabs.Add(mmVM1);

            return new ObservableCollection<ITabControlItem>(tabs);
        }

        public ObservableCollection<ITabControlItem> GetMarketIndexTabs()
        {
            var tabs = new List<ITabControlItem>();

            var mmView = new UsMarketIndexView();
            var mmVM = mmView.DataContext as UsMarketIndexViewModel;
            mmVM.Content = mmView;

            mmVM.Title = "US Index";
            mmVM.ToolTipTitle = "Us Index";

            tabs.Add(mmVM);

            var mmView1 = new JpMarketIndexView();
            var mmVM1 = mmView1.DataContext as JpMarketIndexViewModel;

            mmVM1.Content = mmView;
            mmView1.DataContext = mmVM1;

            mmVM1.Title = "JP Index";
            mmVM1.ToolTipTitle = "JP Index";

            tabs.Add(mmVM1);

            return new ObservableCollection<ITabControlItem>(tabs);
        }
        public ObservableCollection<ITabControlItem> GetMarketExtraTabs()
        {
            var tabs = new List<ITabControlItem>();

            var mmView = new UsMarketIndexView();
            var mmVM = mmView.DataContext as UsMarketIndexViewModel;
            mmVM.Content = mmView;

            mmVM.Title = "US Extra";
            mmVM.ToolTipTitle = "Us Extra Details";

            tabs.Add(mmVM);

            var mmView1 = new JpMarketIndexView();
            var mmVM1 = new JpMarketIndexViewModel();
            mmVM1.Content = mmView1;
            mmView1.DataContext = mmVM1;
            mmVM1.Title = "JP Extra";
            mmVM1.ToolTipTitle = "JP Extra Details";

            tabs.Add(mmVM1);

            return new ObservableCollection<ITabControlItem>(tabs);
        }
    }
}
