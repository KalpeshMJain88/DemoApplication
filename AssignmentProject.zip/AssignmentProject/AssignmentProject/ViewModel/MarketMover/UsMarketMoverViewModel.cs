﻿using AssignmentProject.Controls;
using System;


namespace AssignmentProject.ViewModel
{
    public class UsMarketMoverViewModel : BaseViewModel, ITabControlItem
    {

		public string FreeText { get; set; }
		public UsMarketMoverViewModel()
        {
			FreeText = "US Market Move Page Under Construction.";
		}
		private string _title;
		public string Title
		{
			get { return _title; }
			set
			{
				_title = value;
				RaisePropertyChanged(nameof(Title));
			}
		}


		private string _toolTipTitle;
		public string ToolTipTitle
		{
			get { return _toolTipTitle; }
			set
			{
				_toolTipTitle = value;
				RaisePropertyChanged(nameof(ToolTipTitle));

			}
		}

		private object _content;
		public object Content
		{
			get { return _content; }
			set
			{
				_content = value;
				RaisePropertyChanged(nameof(Content));

			}
		}

		private TabView view;
		public TabView View
		{
			get { return view; }
			set
			{
				view = value;
				RaisePropertyChanged(nameof(View));

			}
		}
	}
}
