﻿using AssignmentProject.Controls;
using AssignmentProject.Model;

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace AssignmentProject.ViewModel
{
    public class EuropeMarketMoverViewModel : BaseViewModel,ITabControlItem
    {
		public EuropeMarketMoverViewModel()
		{
			EuropeScripts1 = new ObservableCollection<EuropeScript>(EuropeScript.GetEuropeScriptDummyData());

			EuropeScripts2 = new ObservableCollection<EuropeScript>(EuropeScript.GetEuropeScriptDummyData());
		}

		private string _title;
		public string Title
		{
			get { return _title; }
			set
			{
				_title = value;
			}
		}


		private string _toolTipTitle;
		public string ToolTipTitle
		{
			get { return _toolTipTitle; }
			set
			{
				_toolTipTitle = value;

			}
		}

		private object _content;
		public object Content
		{
			get { return _content; }
			set
			{
				_content = value;
			}
		}

		private TabView view;
		public TabView View
		{
			get { return view; }
			set
			{
				view = value;

			}
		}

		private ObservableCollection<EuropeScript> _eurScr;
        public ObservableCollection<EuropeScript> EuropeScripts1
		{
			get { return _eurScr; }
			set
			{
				_eurScr = value;
			}
		}

        private ObservableCollection<EuropeScript> _eurScr2;
        public ObservableCollection<EuropeScript> EuropeScripts2
        {
            get { return _eurScr2; }
            set
            {
                _eurScr2 = value;
			}
		}

    }
}