﻿using AssignmentProject.Controls;
using AssignmentProject.View;
using AssignmentProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentProject.ViewModel
{
    class JpMarketMoverViewModel : BaseViewModel, ITabControlItem
    {
		public string FreeText { get; set; }
		public JpMarketMoverViewModel()
        {
			FreeText = "JP Market Move Page Under Construction.";
		}
		private string _title;
		public string Title
		{
			get { return _title; }
			set
			{
				_title = value;
				RaisePropertyChanged(nameof(Title));
			}
		}


		private string _toolTipTitle;
		public string ToolTipTitle
		{
			get { return _toolTipTitle; }
			set
			{
				_toolTipTitle = value;
				RaisePropertyChanged(nameof(ToolTipTitle));

			}
		}

		private object _content;
		public object Content
		{
			get { return _content; }
			set
			{
				_content = value;
				RaisePropertyChanged(nameof(Content));

			}
		}

		private TabView view;
		public TabView View
		{
			get { return view; }
			set
			{
				view = value;
				RaisePropertyChanged(nameof(View));

			}
		}
	}
}

