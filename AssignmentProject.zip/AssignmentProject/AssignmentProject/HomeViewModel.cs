﻿using AssignmentProject.Controls;
using AssignmentProject.View;
using AssignmentProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace AssignmentProject.ViewModel
{
    public class HomeViewModel : BaseViewModel
    {
        public string btnText => "Contact Us";
        public ICommand ContactusCommand { get; set; }

        public List<ITabControlItem> _tabs;// { get; set; }

        public List<string> FontList { get; set; }

        private string selectedFontItem;

        public string SelectedFontItem
        {
            get { return selectedFontItem; }
            set { selectedFontItem = value;
                RaisePropertyChanged();
            }
        }
        private List<string> GetFonts()
        {
            return Fonts.SystemFontFamilies.Select(x => x.Source).ToList();
        }
        public List<ITabControlItem> Tabs
        {
            get { return _tabs; }
            set
            {
                _tabs = value;
                RaisePropertyChanged();
            }
        }
        public HomeViewModel()
        {
            Tabs = GetFunctionalTab();

            FontList = GetFonts();

            ContactusCommand = new Delegatecommand(c,x=> true);
        }

        public void c(object state)
        {
            MessageBox.Show("For More Information Contact us");
        }
        public List<ITabControlItem> GetFunctionalTab()
        {
            var tabs = new List<ITabControlItem>();

            var view = new MarketView();

            var viewmodel = new MarketViewModel();

            viewmodel.Content = view;

            view.DataContext = viewmodel;

            viewmodel.ToolTipTitle = "Market Data";

            viewmodel.Title = "Markets";

            tabs.Add(viewmodel);

            var portfolioTab = new PortfolioView();

            var portfolioVm = new PortfolioViewModel()
            {
                Title="PortFolio",
                ToolTipTitle = "PortFolio View",
                Content = portfolioTab
            };

            portfolioTab.DataContext = portfolioVm;


            tabs.Add(portfolioVm);
            return tabs;
        }
    }
}
