﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentProject.Model
{
    public class UsScript
    {
        public string ScriptName {get;set;}
        public double LastTradedPrice { get; set; }
        public double Move { get; set; }
        public double Change { get; set; }
        public static List<UsScript> GetUsScriptDummyData()
        {
            List<UsScript> data = new List<UsScript>();

            for (int i = 0; i < 100; i++)
            {
                data.Add(new UsScript { ScriptName = $"ACC {i}", LastTradedPrice = 12 + i, Move = 0.05 + i,Change= 10 + i/100 });
            }

            return data;
        }
    }
}
