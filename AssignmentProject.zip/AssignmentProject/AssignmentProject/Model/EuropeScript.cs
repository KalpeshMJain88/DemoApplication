﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentProject.Model
{
    public class EuropeScript
    {
        public string ScriptName { get; set; }
        public double LastTradedPrice { get; set; }
        public double Move { get; set; }
        public double Change { get; set; }
        public static List<EuropeScript> GetEuropeScriptDummyData()
        {
            List<EuropeScript> data = new List<EuropeScript>();

            for (int i = 0; i < 100; i++)
            {
                data.Add(new EuropeScript { ScriptName = $"Telson {i}", LastTradedPrice = 15 + i, Move = 0.09 + i, Change = 10 + i / 100 });
            }

            return data;
        }
    }
}



