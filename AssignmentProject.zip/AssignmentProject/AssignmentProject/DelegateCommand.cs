﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace AssignmentProject
{
    public class Delegatecommand : ICommand
    {
        public event EventHandler CanExecuteChanged;

        private Action<object> _execute ;
        private Predicate<object> _canexcecute;
        public Delegatecommand(Action<object> execute,Predicate<object> canexcecute)
        {
            _execute = execute;
            _canexcecute = canexcecute;
        }
        public bool CanExecute(object parameter)
        {
            if (_canexcecute != null)
            {
                return _canexcecute(parameter);
            }

            return true;
        }

        public void Execute(object parameter)
        {
             _execute(parameter);
        }

        public void RaiseCanExecuteChanged()
        {
            if (CanExecuteChanged != null)
            {
                CanExecuteChanged(this, EventArgs.Empty);
            }
        }
    }
}
