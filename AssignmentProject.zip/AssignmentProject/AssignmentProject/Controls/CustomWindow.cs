﻿using DevExpress.Xpf.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AssignmentProject.Controls
{
    public class CustomWindow : Window
    {
        public string Theme
        {
            get { return (string)GetValue(ThemeProperty); }
            set { SetValue(ThemeProperty, value); }
        }

        public static readonly DependencyProperty ThemeProperty = DependencyProperty.Register("Theme", typeof(string), typeof(CustomWindow), new PropertyMetadata(default(string), ThemePropertyChanged));

        private static void ThemePropertyChanged(DependencyObject dbo, DependencyPropertyChangedEventArgs dpevg)
        {
            var theme = (string)dbo.GetValue(ThemeProperty);
            var window = (CustomWindow)dbo;
            ThemeManager.SetTheme(window, new Theme(theme));

        }

        //public string Font
        //{
        //    get { return (string)GetValue(ThemeProperty); }
        //    set { SetValue(ThemeProperty, value); }
        //}

        //public static readonly DependencyProperty FontProperty = DependencyProperty.Register("Font", typeof(string), typeof(CustomWindow), new PropertyMetadata(default(string), FontChanged));

        //private static void FontChanged(DependencyObject dbo, DependencyPropertyChangedEventArgs dpevg)
        //{
        //    var font = (string)dbo.GetValue(FontProperty);
        //    var window = (CustomWindow)dbo;


        //    var FontFamily = new System.Windows.Media.FontFamily(font);

        //    //window.FontFamily.OverrideMetadata(typeof(CustomWindow), new FrameworkPropertyMetadata(FontFamily));
        //}
    }
}
