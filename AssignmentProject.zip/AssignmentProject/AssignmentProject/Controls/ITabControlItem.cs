﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentProject.Controls
{
    public interface ITabControlItem
    {
        string Title { get; set; }
        string ToolTipTitle { get; set; }
        object Content { get; set; }
        TabView View { get; set; }
    }
}
