﻿using System.Windows;
using System.Windows.Input;
using DevExpress.Xpf.Core;

namespace AssignmentProject.Controls
{
    public class TabControl : System.Windows.Controls.TabControl
    {
        public ICommand CloseCommand;
        //static TabControl()
        //{
        //    DefaultStyleKeyProperty.OverrideMetadata(typeof(AssignmentProject.Controls.TabControl), new FrameworkPropertyMetadata(typeof(TabControl)));
        //}
        public TabControl()
        {
            CloseCommand = new Delegatecommand(Close, CanClose);
        }
        public void Close(object state)
        {
            var item = state as ITabControlItem;
        }

        public bool CanClose(object state)
        {
            return true;
        }

        public string Theme
        {
            get { return (string)GetValue(ThemeProperty); }
            set { SetValue(ThemeProperty, value); }
        }

        public static readonly DependencyProperty ThemeProperty = DependencyProperty.Register("Theme", typeof(string), typeof(TabControl), new PropertyMetadata(default(string), ThemePropertyChanged));

        private static void ThemePropertyChanged(DependencyObject dbo, DependencyPropertyChangedEventArgs dpevg)
        {
            var theme = (string)dbo.GetValue(ThemeProperty);
            var tabcontrol = (TabControl)dbo;
            ThemeManager.SetTheme(tabcontrol, new Theme(theme));
        }
    }
}
