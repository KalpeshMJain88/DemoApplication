﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentProject.Controls
{
    public class TabControlItem : INotifyPropertyChanged ,ITabControlItem
    {
		private string	 _title;
		public  string Title
		{
			get { return _title; }
			set
			{ 
				_title = value;
				OnPropertyChanged(nameof(Title));
			}
		}


		private string _toolTipTitle;
		public string ToolTipTitle
		{
			get { return _toolTipTitle; }
			set
			{
				_toolTipTitle = value;
				OnPropertyChanged(nameof(ToolTipTitle));

			}
		}

		private object _content;
		public object Content
		{
			get { return _content; }
			set
			{
				_content =  value;
				OnPropertyChanged(nameof(Content));

			}
		}

		private TabView view;

		public event PropertyChangedEventHandler PropertyChanged;

		public TabView View
		{
			get { return view; }
			set { 
				view = value;
				OnPropertyChanged(nameof(View));

			}
		}

		public void OnPropertyChanged(string name)
		{
			PropertyChanged(this, new PropertyChangedEventArgs(name));
		}

		public TabControlItem()
		{

		}

	}
}
