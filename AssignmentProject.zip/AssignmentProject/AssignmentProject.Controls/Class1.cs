﻿using System;

namespace AssignmentProject.Controls
{
    public class TabControl1 : TabControl
    {
        1
    }
}
